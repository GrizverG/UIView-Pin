//
//  FirstRouter.swift
//  CleanSwift
//
//  Created by Gregory Pinetree on 20.01.2023.
//

import UIKit

final class FirstRouter: FirstRoutingLogic {
    weak var view: UIViewController?

    func routeTo() {

    }
}
